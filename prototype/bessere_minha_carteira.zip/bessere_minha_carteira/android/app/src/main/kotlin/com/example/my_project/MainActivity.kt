package com.mycompany.identitywallet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
