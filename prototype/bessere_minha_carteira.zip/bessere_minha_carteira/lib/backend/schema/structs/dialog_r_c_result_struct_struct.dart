// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DialogRCResultStructStruct extends BaseStruct {
  DialogRCResultStructStruct({
    bool? revokeDN,
    bool? revokeAddress,
  })  : _revokeDN = revokeDN,
        _revokeAddress = revokeAddress;

  // "revokeDN" field.
  bool? _revokeDN;
  bool get revokeDN => _revokeDN ?? false;
  set revokeDN(bool? val) => _revokeDN = val;

  bool hasRevokeDN() => _revokeDN != null;

  // "revokeAddress" field.
  bool? _revokeAddress;
  bool get revokeAddress => _revokeAddress ?? false;
  set revokeAddress(bool? val) => _revokeAddress = val;

  bool hasRevokeAddress() => _revokeAddress != null;

  static DialogRCResultStructStruct fromMap(Map<String, dynamic> data) =>
      DialogRCResultStructStruct(
        revokeDN: data['revokeDN'] as bool?,
        revokeAddress: data['revokeAddress'] as bool?,
      );

  static DialogRCResultStructStruct? maybeFromMap(dynamic data) => data is Map
      ? DialogRCResultStructStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'revokeDN': _revokeDN,
        'revokeAddress': _revokeAddress,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'revokeDN': serializeParam(
          _revokeDN,
          ParamType.bool,
        ),
        'revokeAddress': serializeParam(
          _revokeAddress,
          ParamType.bool,
        ),
      }.withoutNulls;

  static DialogRCResultStructStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      DialogRCResultStructStruct(
        revokeDN: deserializeParam(
          data['revokeDN'],
          ParamType.bool,
          false,
        ),
        revokeAddress: deserializeParam(
          data['revokeAddress'],
          ParamType.bool,
          false,
        ),
      );

  @override
  String toString() => 'DialogRCResultStructStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is DialogRCResultStructStruct &&
        revokeDN == other.revokeDN &&
        revokeAddress == other.revokeAddress;
  }

  @override
  int get hashCode => const ListEquality().hash([revokeDN, revokeAddress]);
}

DialogRCResultStructStruct createDialogRCResultStructStruct({
  bool? revokeDN,
  bool? revokeAddress,
}) =>
    DialogRCResultStructStruct(
      revokeDN: revokeDN,
      revokeAddress: revokeAddress,
    );
