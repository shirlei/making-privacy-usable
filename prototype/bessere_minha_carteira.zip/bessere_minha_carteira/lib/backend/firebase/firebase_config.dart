import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCd2HcLBiSkDQPwxeCdHlqXVomdh9HHCLw",
            authDomain: "identity-wallet-51uk6y.firebaseapp.com",
            projectId: "identity-wallet-51uk6y",
            storageBucket: "identity-wallet-51uk6y.firebasestorage.app",
            messagingSenderId: "387943384686",
            appId: "1:387943384686:web:6da3920e6d181c6742887f"));
  } else {
    await Firebase.initializeApp();
  }
}
