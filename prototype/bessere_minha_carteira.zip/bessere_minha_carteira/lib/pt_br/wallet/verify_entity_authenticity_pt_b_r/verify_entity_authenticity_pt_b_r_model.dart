import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/pt_br/components/bottom_sheet_confirmations_pt_br/bottom_sheet_confirmations_pt_br_widget.dart';
import '/pt_br/components/nudge_protect_your_privacy/nudge_protect_your_privacy_widget.dart';
import '/pt_br/components/privacy_notice_component_minimal/privacy_notice_component_minimal_widget.dart';
import '/pt_br/components/titulo_descricao/titulo_descricao_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'verify_entity_authenticity_pt_b_r_widget.dart'
    show VerifyEntityAuthenticityPtBRWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class VerifyEntityAuthenticityPtBRModel
    extends FlutterFlowModel<VerifyEntityAuthenticityPtBRWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for tituloDescricao component.
  late TituloDescricaoModel tituloDescricaoModel;
  // Model for nudgeProtectYourPrivacy component.
  late NudgeProtectYourPrivacyModel nudgeProtectYourPrivacyModel;

  @override
  void initState(BuildContext context) {
    tituloDescricaoModel = createModel(context, () => TituloDescricaoModel());
    nudgeProtectYourPrivacyModel =
        createModel(context, () => NudgeProtectYourPrivacyModel());
  }

  @override
  void dispose() {
    tituloDescricaoModel.dispose();
    nudgeProtectYourPrivacyModel.dispose();
  }
}
