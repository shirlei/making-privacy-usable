import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/pt_br/components/bottom_sheet_credentials_s_d_pt_br/bottom_sheet_credentials_s_d_pt_br_widget.dart';
import '/pt_br/components/bottom_sheet_requested_data_details_pt_br/bottom_sheet_requested_data_details_pt_br_widget.dart';
import '/pt_br/components/titulo_descricao/titulo_descricao_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'review_requested_data_pt_b_r_widget.dart'
    show ReviewRequestedDataPtBRWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ReviewRequestedDataPtBRModel
    extends FlutterFlowModel<ReviewRequestedDataPtBRWidget> {
  ///  Local state fields for this page.
  /// data de nascimento
  String? dtNascimento = '';

  String dtNascimentoDraggable = '23/10/1989';

  String cepDraggable = '88001-002';

  String? cep = '';

  ///  State fields for stateful widgets in this page.

  // Model for tituloDescricao component.
  late TituloDescricaoModel tituloDescricaoModel;

  @override
  void initState(BuildContext context) {
    tituloDescricaoModel = createModel(context, () => TituloDescricaoModel());
  }

  @override
  void dispose() {
    tituloDescricaoModel.dispose();
  }
}
