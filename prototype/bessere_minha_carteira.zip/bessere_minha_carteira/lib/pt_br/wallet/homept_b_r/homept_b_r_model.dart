import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/pt_br/components/btn_review_sharing/btn_review_sharing_widget.dart';
import 'dart:ui';
import 'homept_b_r_widget.dart' show HomeptBRWidget;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HomeptBRModel extends FlutterFlowModel<HomeptBRWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Button.
  late BtnReviewSharingModel buttonModel;

  @override
  void initState(BuildContext context) {
    buttonModel = createModel(context, () => BtnReviewSharingModel());
  }

  @override
  void dispose() {
    buttonModel.dispose();
  }
}
