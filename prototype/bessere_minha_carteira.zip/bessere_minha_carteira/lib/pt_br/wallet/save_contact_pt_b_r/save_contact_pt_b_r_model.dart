import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_toggle_icon.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/pt_br/components/privacy_notice_component_minimal/privacy_notice_component_minimal_widget.dart';
import '/pt_br/components/titulo_descricao/titulo_descricao_widget.dart';
import '/pt_br/components/toast_confirmation/toast_confirmation_widget.dart';
import 'dart:ui';
import 'save_contact_pt_b_r_widget.dart' show SaveContactPtBRWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SaveContactPtBRModel extends FlutterFlowModel<SaveContactPtBRWidget> {
  ///  Local state fields for this page.

  bool isDontSaveContactActive = false;

  bool isSaveContactActive = false;

  ///  State fields for stateful widgets in this page.

  // Model for tituloDescricao component.
  late TituloDescricaoModel tituloDescricaoModel;

  @override
  void initState(BuildContext context) {
    tituloDescricaoModel = createModel(context, () => TituloDescricaoModel());
  }

  @override
  void dispose() {
    tituloDescricaoModel.dispose();
  }
}
