import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'loading_minha_carteira_widget.dart' show LoadingMinhaCarteiraWidget;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LoadingMinhaCarteiraModel
    extends FlutterFlowModel<LoadingMinhaCarteiraWidget> {
  ///  Local state fields for this component.

  int temp = 0;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
