import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'modal_open_wallet_pt_br_widget.dart' show ModalOpenWalletPtBrWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ModalOpenWalletPtBrModel
    extends FlutterFlowModel<ModalOpenWalletPtBrWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
