import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'toast_confirmation_widget.dart' show ToastConfirmationWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ToastConfirmationModel extends FlutterFlowModel<ToastConfirmationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
