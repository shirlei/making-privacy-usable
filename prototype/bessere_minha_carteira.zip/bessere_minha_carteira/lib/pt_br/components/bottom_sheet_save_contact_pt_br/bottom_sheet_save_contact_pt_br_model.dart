import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_toggle_icon.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/pt_br/components/modal_header_close/modal_header_close_widget.dart';
import '/pt_br/components/privacy_notice_component_minimal/privacy_notice_component_minimal_widget.dart';
import '/pt_br/components/toast_confirmation/toast_confirmation_widget.dart';
import 'dart:ui';
import 'bottom_sheet_save_contact_pt_br_widget.dart'
    show BottomSheetSaveContactPtBrWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BottomSheetSaveContactPtBrModel
    extends FlutterFlowModel<BottomSheetSaveContactPtBrWidget> {
  ///  Local state fields for this component.

  bool isSaveContactActive = false;

  bool isDontSaveContactActive = false;

  ///  State fields for stateful widgets in this component.

  // Model for modalHeaderClose component.
  late ModalHeaderCloseModel modalHeaderCloseModel;

  @override
  void initState(BuildContext context) {
    modalHeaderCloseModel = createModel(context, () => ModalHeaderCloseModel());
  }

  @override
  void dispose() {
    modalHeaderCloseModel.dispose();
  }
}
