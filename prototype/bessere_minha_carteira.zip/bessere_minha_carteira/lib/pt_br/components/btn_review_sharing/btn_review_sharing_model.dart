import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'btn_review_sharing_widget.dart' show BtnReviewSharingWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:provider/provider.dart';

class BtnReviewSharingModel extends FlutterFlowModel<BtnReviewSharingWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
