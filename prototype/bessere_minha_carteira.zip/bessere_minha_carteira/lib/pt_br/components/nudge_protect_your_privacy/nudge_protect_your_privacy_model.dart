import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'nudge_protect_your_privacy_widget.dart'
    show NudgeProtectYourPrivacyWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NudgeProtectYourPrivacyModel
    extends FlutterFlowModel<NudgeProtectYourPrivacyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
