import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'toast_not_available_widget.dart' show ToastNotAvailableWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ToastNotAvailableModel extends FlutterFlowModel<ToastNotAvailableWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
