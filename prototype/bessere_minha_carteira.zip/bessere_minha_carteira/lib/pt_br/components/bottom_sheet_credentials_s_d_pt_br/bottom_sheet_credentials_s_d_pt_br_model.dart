import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/pt_br/components/modal_header_close/modal_header_close_widget.dart';
import 'dart:ui';
import 'bottom_sheet_credentials_s_d_pt_br_widget.dart'
    show BottomSheetCredentialsSDPtBrWidget;
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BottomSheetCredentialsSDPtBrModel
    extends FlutterFlowModel<BottomSheetCredentialsSDPtBrWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for modalHeaderClose component.
  late ModalHeaderCloseModel modalHeaderCloseModel;

  @override
  void initState(BuildContext context) {
    modalHeaderCloseModel = createModel(context, () => ModalHeaderCloseModel());
  }

  @override
  void dispose() {
    modalHeaderCloseModel.dispose();
  }
}
