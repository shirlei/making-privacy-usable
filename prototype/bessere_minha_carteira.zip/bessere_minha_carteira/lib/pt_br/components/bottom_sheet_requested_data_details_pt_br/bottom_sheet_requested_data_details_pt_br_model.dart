import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/pt_br/components/modal_header_close/modal_header_close_widget.dart';
import 'dart:ui';
import 'bottom_sheet_requested_data_details_pt_br_widget.dart'
    show BottomSheetRequestedDataDetailsPtBrWidget;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class BottomSheetRequestedDataDetailsPtBrModel
    extends FlutterFlowModel<BottomSheetRequestedDataDetailsPtBrWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for modalHeaderClose component.
  late ModalHeaderCloseModel modalHeaderCloseModel;

  @override
  void initState(BuildContext context) {
    modalHeaderCloseModel = createModel(context, () => ModalHeaderCloseModel());
  }

  @override
  void dispose() {
    modalHeaderCloseModel.dispose();
  }
}
