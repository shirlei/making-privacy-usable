import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/pt_br/components/modal_header_close/modal_header_close_widget.dart';
import 'dart:ui';
import 'privacy_notice_component_minimal_widget.dart'
    show PrivacyNoticeComponentMinimalWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PrivacyNoticeComponentMinimalModel
    extends FlutterFlowModel<PrivacyNoticeComponentMinimalWidget> {
  ///  State fields for stateful widgets in this component.

  // Model for modalHeaderClose component.
  late ModalHeaderCloseModel modalHeaderCloseModel;

  @override
  void initState(BuildContext context) {
    modalHeaderCloseModel = createModel(context, () => ModalHeaderCloseModel());
  }

  @override
  void dispose() {
    modalHeaderCloseModel.dispose();
  }
}
