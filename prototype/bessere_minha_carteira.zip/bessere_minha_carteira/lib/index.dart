// Export pages
export '/pt_br/bessereonboarding/create_account_pt_br/create_account_pt_br_widget.dart'
    show CreateAccountPtBrWidget;
export '/pt_br/bessereonboarding/login_pt_br/login_pt_br_widget.dart'
    show LoginPtBrWidget;
export '/pt_br/bessereonboarding/onboarded_pt_br/onboarded_pt_br_widget.dart'
    show OnboardedPtBrWidget;
export '/pt_br/wallet/verify_entity_authenticity_pt_b_r/verify_entity_authenticity_pt_b_r_widget.dart'
    show VerifyEntityAuthenticityPtBRWidget;
export '/pt_br/wallet/review_requested_data_pt_b_r/review_requested_data_pt_b_r_widget.dart'
    show ReviewRequestedDataPtBRWidget;
export '/pt_br/wallet/save_contact_pt_b_r/save_contact_pt_b_r_widget.dart'
    show SaveContactPtBRWidget;
export '/loading_page/loading_page_widget.dart' show LoadingPageWidget;
export '/pt_br/wallet/homept_b_r/homept_b_r_widget.dart' show HomeptBRWidget;
