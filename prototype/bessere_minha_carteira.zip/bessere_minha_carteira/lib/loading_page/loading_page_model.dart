import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/pt_br/components/botton_sheet_open_wallet_pt_br/botton_sheet_open_wallet_pt_br_widget.dart';
import '/pt_br/components/loading_minha_carteira/loading_minha_carteira_widget.dart';
import 'dart:ui';
import 'loading_page_widget.dart' show LoadingPageWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LoadingPageModel extends FlutterFlowModel<LoadingPageWidget> {
  ///  Local state fields for this page.

  bool? showUseWallet;

  ///  State fields for stateful widgets in this page.

  // Model for LoadingMinhaCarteira component.
  late LoadingMinhaCarteiraModel loadingMinhaCarteiraModel;
  // Model for BottonSheetOpenWallet_pt_br component.
  late BottonSheetOpenWalletPtBrModel bottonSheetOpenWalletPtBrModel;

  @override
  void initState(BuildContext context) {
    loadingMinhaCarteiraModel =
        createModel(context, () => LoadingMinhaCarteiraModel());
    bottonSheetOpenWalletPtBrModel =
        createModel(context, () => BottonSheetOpenWalletPtBrModel());
  }

  @override
  void dispose() {
    loadingMinhaCarteiraModel.dispose();
    bottonSheetOpenWalletPtBrModel.dispose();
  }
}
